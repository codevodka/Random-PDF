import os
import re

directory = "G:/0 EXTRA/LINUX/Udemy - Bash  Shell  100 Hands On Challenge with 10 Live Projects 2024-9/4 - Bash Commands Practice Questions Beginner Level Question 1 25"
files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

# Custom sort function to extract numeric prefix
def get_numeric_prefix(filename):
    match = re.match(r"(\d+)", filename)
    return int(match.group(1)) if match else float('inf')  # Use 'inf' for files without numeric prefix

# Sort based on numeric prefix
sorted_files = sorted(files, key=get_numeric_prefix)
sorted_files = sorted_files[1:]
print(sorted_files)

sorted_html = ""
for link in sorted_files:
	sorted_html += f"<tr><td>1</td><td><a href='{link}'>{link}</a></td></tr>"

with open('00.html', 'w') as file:
	file.write(sorted_html)
		

