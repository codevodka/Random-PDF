# Proxmox VE Fundamentals Reference Links

Happy learning! -Tim

## Contact information

- [Tim Warner](mailto:tim-warner@pluralsight.com)
- [Website](https://techtrainertim.com)
- [Bluesky](https://bsky.app/profile/techtrainertim.bsky.social)
- [Mastodon](https://mastodon.social/@techtrainertim)
- [LinkedIn](https://www.linkedin.com/in/timothywarner/)

## Proxmox resources

- [Proxmox VE Documentation](https://pve.proxmox.com/pve-docs/)
- [Proxmox VE Developer Documentation](https://pve.proxmox.com/wiki/Developer_Documentation)
- [Proxmox VE YouTube channel](https://www.youtube.com/user/ProxmoxVE)
- [Proxmox VE Forum](https://forum.proxmox.com/)
- [Proxmox VE Wiki](https://pve.proxmox.com/wiki/Main_Page)
- [Proxmox VE GitHub](https://github.com/proxmox)
- [Proxmox VE on Reddit](https://www.reddit.com/r/Proxmox/)

## Third-party books

- [Proxmox High Availability](https://www.packtpub.com/product/proxmox-high-availability/9781788397611)
- [Mastering Proxmox](https://www.packtpub.com/product/mastering-proxmox/9781783981786)
- [Proxmox Cookbook](https://www.packtpub.com/product/proxmox-cookbook/9781785884439)
- [Practical Linux DevOps](https://www.packtpub.com/product/practical-linux-devops/9781788625443)
